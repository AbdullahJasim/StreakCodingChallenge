module.exports = {
    "name": "Rate Limiting Take Home",
    "verbose": true
};